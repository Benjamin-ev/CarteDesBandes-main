# CarteDesBandes
Pour faire une carte des bandes

# Structure
App : backend en php pour gestion bdd<br />
layout : fichiers utile pour le frontend (img fonts)<br />
le reste des fichiers (js/html) font partie du frontend<br />

# Todo
- xsrf && xss issues
- docker en cours
- Il manque la syncro avec la base ldap
